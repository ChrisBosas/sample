<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
    <script type="text/javascript" src="js/javascript.js"></script>
    
    <script type="text/javascript">
      $(function() {
        $("#lets_search1").bind('submit',function() {
          var value = $('#str1').val();
          if(value == ""){
            
          }else{ 
            $.post('mySearch.php',{value:value}, function(data){
             $("#search_results1").html(data);
           });
           return false;
          }
        });
      });
    </script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script type="text/javascript">
      $(function() {
         $( "#str1" ).autocomplete({
           source: 'mySearch.php',
         });
      });
    </script>

</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Button used to open the chat form - fixed at the bottom of the page */
.open-button {
  /* background-color: #555; */
  background-color: transparent;
  /* color: white; */
  /* padding: 16px 20px; */
  border: none;
  cursor: pointer;
  /* opacity: 0.8; */
  position: fixed;
  bottom: 23px;
  right: 28px;
  /* width: 280px; */
  width: 100px;
}

/* The popup chat - hidden by default */
.chat-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width textarea */
.form-container textarea {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
  resize: none;
  min-height: 25px;
}

/* When the textarea gets focus, do something */
.form-container textarea:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/send button */
.form-container .btn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 49%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
<style>
  
.container {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}

.darker {
  border-color: #ccc;
  background-color: #ddd;
}

.container::after {
  content: "";
  clear: both;
  display: table;
}

.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
}

.time-left {
  float: left;
  color: #999;
}

.chatbot-btn {
  /* float: left; */
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

[contenteditable] {
  outline: 0px solid transparent;
}
</style>
<style>
  div .scroll {
    background-color: transparent;
    width: 100%;
    height: 350px;
    overflow-x: hidden;
    overflow-y: auto;
    /* text-align: center; */
    padding: 2px;
  }
</style>

<style>
/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>

<body>
<div class="search-wrapper active">
    <div class="input-holder">
        <form id="lets_search1" action="">
            <input type="text" class="search-input" placeholder="Type to search" name="str1"  id="str1"/>
            <button class="search-icon" onclick="searchToggle(this, event);" value="myBtn" name="myBtn" id="myBtn"><span></span></button>
        </form>
    </div>
    <br>
</div>

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <p><div class="card" id="search_results1"></div></p>
  </div>

</div>


<button class="open-button" onclick="openForm()"><img src="img/chatbot-icon.png" alt="Avatar" style="width:100%;"></button>

<div class="chat-popup" id="myForm">
  <form action="/action_page.php" class="form-container">
    <h1>Talk to Chatbot</h1>

    <label for="msg"><b>Message</b></label>
      
      <div class="scroll">
        <div class="container">
          <img src="img/chatbot-guess-icon.png" alt="Avatar" style="width:100%;">
          <p contenteditable="true">Sample Question 1?</p>
          <span class="time-right">11:00</span>
        </div>

        <div class="container darker">
          <img src="img/chatbot.png" alt="Avatar" class="right" style="width:100%;">
          <p contenteditable="true">Sample Answer for Question 1. :)</p>
          <span class="time-left">11:01</span>
        </div>

        <div class="container">
          <img src="img/chatbot-guess-icon.png" alt="Avatar" style="width:100%;">
          <p contenteditable="true">Sample Question 2?</p>
          <span class="time-right">11:03</span>
        </div>
        
        <div class="container darker">
          <img src="img/chatbot.png" alt="Avatar" class="right" style="width:100%;">
          <p contenteditable="true">Sample Answer for Question 2. :)</p>
          <span class="time-left">11:04</span>
        </div>
      </div>

    <textarea placeholder="Type message.." name="msg" required></textarea>

    <button type="submit" class="btn">Send</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>
    
</body>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>
<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";

  // When the user clicks the button while open the chatbot, open the modal and close the chatbot
  document.getElementById("myForm").style.display = "none";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
</html>