<?php
require('config/conn.php'); 
session_start();

$sql = "SELECT * FROM books WHERE title LIKE '%".$_POST['value']."%' || tags LIKE '%".$_POST['value']."%' ";

if ($result = $con -> query($sql)) {
  while ($row = $result -> fetch_assoc()) {

    $id = $row["id"];
    $title = $row["title"];
    $tags= $row["tags"];
    $link = $row["link"];
    $body = $row["body"];

  ?>
        <br>
        <div style = "float:left;">
            <span hidden> ID : <?php echo $id; ?> </span>
        </div>
        <br>
        <div style = "float:left;">
            <span> Title : <?php echo $title; ?> </span>
        </div>
        <br>
        <div style = "float:left;">
            <span> Tags : <?php echo $tags; ?> </span>
        </div>
        <br>
        <div style = "float:left;">
            <span> Link : <?php echo preg_replace("~(https?://(?:www\.)?[^\s]+)~i","<a href='$1'>$1</a>",$link); ?> </span>
        </div>
        <br>
        <div style = "float:left;">
            <span> Body : <br> <?php echo $body; ?> </span>
        </div>
        <br>
        
    <br>
    <hr>
    <br>
    
<?php
  }

}

?>
